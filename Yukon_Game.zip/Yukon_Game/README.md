# Running with build:
1. Open MOP_2 Project Folder in terminal. And run these:
2. mkdir build
3. cd build
4. cmake ..
5. cmake --build .

Then move the MOP_2.exe and server.exe into the Executables folder, and you should be able to continue by following the instructions below:

# Running without building on WINDOWS 
(In case build fails, this should still work)

## For text-based / terminal game:
Run:
Open the Executables and run the MOP_2.exe file (may give you a windows defender alert).

## For GUI game:
Run:
Launch the LAUNCH_ME_GUI bat file. (Otherwise open Server.exe in Executables, then launch main.py in Python_GUI)