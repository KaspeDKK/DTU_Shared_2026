@echo off
cd /d "%~dp0"

echo Starting server...
start "" "%~dp0Executables\server.exe"

timeout /t 1 >nul

echo Starting Python GUI...
cd /d "%~dp0python_gui"
python main.py

pause