package com.example.accessing_data_rest.services;

import com.example.accessing_data_rest.exceptions.CouldNotUpdateGameStateException;
import com.example.accessing_data_rest.exceptions.IllegalPlayerCountException;
import com.example.accessing_data_rest.model.Game;
import com.example.accessing_data_rest.model.Player;
import com.example.accessing_data_rest.model.User;
import com.example.accessing_data_rest.repositories.GameRepository;
import com.example.accessing_data_rest.repositories.PlayerRepository;
import com.example.accessing_data_rest.repositories.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class GameService {

    @Autowired
    private GameRepository gameRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private UserService userService;
    @Autowired
    private PlayerRepository playerRepository;

    /**
     *
     * @return a list of all games from the repository
     */
    public List<Game> getGames() {
        List<Game> games = new ArrayList<>();
        gameRepository.findAll().forEach(games::add);
        return games;
    }

    /**
     * Creates a game in the repository and returns the result. The game must have at least 2 players, and the owner must be an existing user in the repository.
     * The owner is also added as the first player of the game.
     *
     * @param game The game to create. The owner must be an existing user in the repository, and the game must have at least 2 players and at max 6 players.
     * @return The created game with the owner and the first player set to the owner.
     * @throws IllegalPlayerCountException If the game has less than 2 players or if the owner is not an existing user in the repository or if there are more than 6 players.
     */
    @Transactional
    public Game createGame(Game game) {

        List<User> users = userRepository.findByName(game.getOwner().getName());
        if (users.isEmpty()) throw new IllegalPlayerCountException("Game must have at least 2 players and at max 6 players, and the owner must be an existing user in the repository.");
        User owner = users.getFirst();

        if (game.getMinPlayers() > game.getMaxPlayers()) {
            throw new IllegalPlayerCountException("Cannot create game with more minum amount of players than maximum amount of players.");
        }

        if (game.getMinPlayers() >= 2 && game.getMaxPlayers() <= 6 && owner != null) {

            game.setOwner(owner);  // Now game points to user

            Game savedGame = gameRepository.save(game);  // Game now has ID

            Player player = new Player();
            player.setGame(savedGame);   // Managed game
            player.setUser(owner);       // Managed user
            player.setName(owner.getName());
            playerRepository.save(player);

            return gameRepository.findByUid(savedGame.getUid()).get(0);

        } else {
            throw new IllegalPlayerCountException("Game must have at least 2 players and at max 6 players, and the owner must be an existing user in the repository.");
        }

    }

    /** updates the state of the game. This is used when handling going from sign up / sign in ---> ACTIVE (an ongoing game)
     *
     * @param gameUid of the game to change the gameState
     * @param gameState the gameState enum to attribute your game
     * @return an updated game
     */
    @Transactional
    public Game updateGameState(long gameUid, Game.GameState gameState) {
        Game existingGame = gameRepository.findByUid(gameUid).get(0);

        if (existingGame.getGameState() == Game.GameState.FINISHED){
            throw new CouldNotUpdateGameStateException("Game has already been finished");
        }

        if (existingGame == null) {
            throw new CouldNotUpdateGameStateException("Game with uid " + gameUid + " does not exist.");
        }

        if(existingGame.getPlayers().size() < existingGame.getMinPlayers() ) {
            throw new IllegalPlayerCountException("Game with uid " + gameUid + " does not have enough players to start. Minimum players required: " + existingGame.getMinPlayers());
        }
        existingGame.setGameState(gameState);
        return gameRepository.save(existingGame);
    }

    /**
     *
     * @param gameUid of the game to delete
     */
    @Transactional
    public void deleteGame(long gameUid) {
        gameRepository.deleteById(gameUid);
    }

}
