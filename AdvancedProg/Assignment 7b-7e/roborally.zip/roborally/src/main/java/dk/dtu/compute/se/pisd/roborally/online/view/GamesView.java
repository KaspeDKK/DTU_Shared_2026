package dk.dtu.compute.se.pisd.roborally.online.view;

import dk.dtu.compute.se.pisd.roborally.online.controller.OnlineController;
import dk.dtu.compute.se.pisd.roborally.online.model.Game;

import dk.dtu.compute.se.pisd.roborally.online.model.Player;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;

import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.text.TextFlow;

public class GamesView extends GridPane {

    public static final int width = 640;
    public static final int height = 400;

    private OnlineController onlineController;

    public GamesView(OnlineController onlineController, GameSelection gameSelection) {
        this.onlineController = onlineController;
        this.setPadding(new Insets(5, 5, 5, 5));
        this.getColumnConstraints().add(new ColumnConstraints(300));
        this.getColumnConstraints().add(new ColumnConstraints(80));
        this.getColumnConstraints().add(new ColumnConstraints(80));
        this.getColumnConstraints().add(new ColumnConstraints(80));
        this.getColumnConstraints().add(new ColumnConstraints(80));

        update();
    }

    /** Updates the GameView. This handles flowcontrol safeguarding by only allowing specific event inputs on the view under certain circumstances:
     *  <p>- Join button is enabled if player count is lower than maximum player count or if a user is a part of the game (and maybe has left the game and wants to join again), and... </p>
     *  <p>- Leave button is enabled if user is not the owner of the game or if the game has started, and...</p>
     *  <p>- Start button is enabled if game hasn't started yet, and you have joined the gamelobby. Play is enabled if the game already has started, and...</p>
     *  <p>- Delete button is enabled only if the user signed in the view / onlineController is the game owner</p>
     */

    private void update() {
        try {
            int i = 0;
            for (Game game: onlineController.onlineState.getOpenGames() ) {

                TextFlow gameInfo = new TextFlow();

                Text gameName = new Text(
                        "Game: " + game.getName() +
                                " (min: " + game.getMinPlayers() +
                                ", max: " + game.getMaxPlayers() + ")" );
                gameInfo.getChildren().add(gameName);


                for (Player player: game.getPlayers()) {
                    Text playerInfo = new Text("\n  Player " + player.getName());
                    gameInfo.getChildren().add(playerInfo);

                }
                gameInfo.setTextAlignment(TextAlignment.LEFT);
                gameInfo.setLineSpacing(1.0);
                gameInfo.setPrefWidth(190);

                Button joinButton = new Button("Join");
                joinButton.setOnAction( e -> {
                    try {
                        onlineController.joinGame(game);
                    } catch (Exception exception) {
                        // probably not needed since joinGame should catch possible exceptions
                    }
                });
                if (game.getPlayers().size() >= game.getMaxPlayers() || onlineController.userInGame(game)) {
                    joinButton.setDisable(true);
                } else {
                    joinButton.setDisable(false);
                }

                Button leaveButton = new Button("Leave");
                leaveButton.setOnAction( e -> {
                    try {
                        for (Player player: game.getPlayers()) {
                            if (player.getUser().getUid() == (onlineController.onlineState.getSignedInUser().getUid())) {
                                onlineController.leaveGame(player);
                            }
                        }


                    } catch (Exception exception) {
                        // probably not needed since joinGame should catch possible exceptions
                        /*
                        Label text = new Label("There was a problem leaving the game");
                        this.add(text, 0, 0);
                        exception.printStackTrace();

                         */
                    }
                });
                if (!onlineController.userInGame(game) || onlineController.userOwnsGame(game)) {
                    leaveButton.setDisable(true);
                } else {
                    leaveButton.setDisable(false);
                }

                Button startButton = new Button();
                startButton.setOnAction( e -> onlineController.gameSelected(game) );
                if (game.getGameState() == Game.GameState.ACTIVE) {
                    startButton.setText("Play");
                } else {
                    startButton.setText("Start");
                }
                if (game.getMinPlayers() <= game.getPlayers().size() &&
                        game.getMaxPlayers() >= game.getPlayers().size() &&
                        onlineController.userInGame(game) &&
                        onlineController.userOwnsGame(game)) {
                    startButton.setDisable(false);
                } else {
                    startButton.setDisable(true);
                }

                Button deleteButton = new Button("Delete");
                deleteButton.setOnAction(
                        e -> onlineController.deleteGame(game) );
                if (onlineController.userOwnsGame(game)) {
                    deleteButton.setDisable(false);
                } else {
                    deleteButton.setDisable(true);
                }


                this.add(gameInfo, 0, i);
                this.add(joinButton, 1, i);
                this.add(leaveButton, 2, i);
                this.add(startButton, 3, i);
                this.add(deleteButton, 4, i);
                i++;
            }
        } catch (Exception e) {
            Label text = new Label("There was a problem with loading the games.");
            this.add(text, 0,0);
            e.printStackTrace();

        }
    }

}
