package dk.dtu.compute.se.pisd.roborally.online.controller;

import dk.dtu.compute.se.pisd.roborally.controller.AppController;
import dk.dtu.compute.se.pisd.roborally.controller.GameController;
import dk.dtu.compute.se.pisd.roborally.model.Board;
import dk.dtu.compute.se.pisd.roborally.online.model.*;
import dk.dtu.compute.se.pisd.roborally.online.view.AppDialogs;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClient;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class OnlineController {


    public final AppController appController;

    public final OnlineState onlineState;

    private AppDialogs appDialogs;

    /**
     * The root URL of the backend for all the REST services.
     */
    public final String ROBORALLY_BACKEND_URL = "http://localhost:8080/roborally/";

    /**
     * The RestClient that can be used throughout all functions of this OnlineController
     * to communicate with the RoboRally backend.
     */
    private RestClient restClient;

    /** constructor for the OnlineController object which contains an appController, onlineState, restClient and appDialogs
     *
     * @param appController for your current app
     */
    public OnlineController(AppController appController) {
        this.appController = appController;
        this.onlineState = new OnlineState();
        restClient = RestClient.builder().
                baseUrl(ROBORALLY_BACKEND_URL).
                build();
        this.appDialogs = new AppDialogs(this);
    }

    /** Sign In with your given unique username
     *
     * @param name of your user
     */
    public void signIn(String name) {
        List<User> users = restClient.get()
                .uri(uriBuilder -> uriBuilder //lambda function
                        .path("/user/search") //determines path of endpoint
                        .queryParam("name", name) //adds the query parameter to the URL
                        .build())//builds the JSON
                .retrieve() // gets response from backend
                .body(new ParameterizedTypeReference<>() {
                }); //typecasts the JSON response to User
        assert users != null;
        if (!users.isEmpty()) {
            setOnlineUser(users.get(0));
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText("User not found");
            alert.showAndWait();
        }
    }

    /** Method to enter signIn appDialog / signIn-section, where you enter your credentials.
     * Note that this does in fact NOT sign you in.
     *
     */
    public void signIn() {
        if (appController.isGameRunning()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Game running");
            alert.setHeaderText("You cannot sign in while a game is running!");
            alert.showAndWait();
        } else if (gameSelectionOn) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Game selection is active");
            alert.setHeaderText(
                    "You cannot sign in while a game selection " +
                            "for a signed in user is active!");
            alert.showAndWait();
        } else {
            appDialogs.signIn();
        }
    }

    /** current signed-in user will be signed out after doing a signOut confirmation
     *
     */
    public void signOut() {
        if (onlineState.getSignedInUser() != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Sign out?");
            alert.setContentText(
                    "Are you sure you want to sign out, " + onlineState.getSignedInUser().getName() + "?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                // If the user confirms, sign the user out
                setOnlineUser(null);
            }
        }
    }

    /** Signs up user with the given name. This is a POST method to create this new user with the given name.
     * A server side error can be thrown from UserService, passed to UserController and finally caught clientside in this method.
     *
     * @param name you want to assign to your user
     */

    public void signUp(String name) {
        try {
            User user = new User();
            user.setName(name);
            user = restClient.post()
                    .uri("/user")
                    .body(user)
                    .retrieve()
                    .body(User.class);
            setOnlineUser(user);
        } catch (HttpClientErrorException.Conflict e) { //catches the conflict that is returned in the server side - See README
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(e.getMessage());
            alert.showAndWait();
        }
    }

    /** signIn button function which will open up signUp appDialogs / signUp section, where you enter credentials for your signUp.
     * You cannot signUp if a game is running or
     *
     */
    public void signUp() {
        if (appController.isGameRunning()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Game running");
            alert.setHeaderText("You cannot sign in while a game is running!");
            alert.showAndWait();
        } else if (gameSelectionOn) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Game selection is active");
            alert.setHeaderText("You cannot sign up while a game is running!");
            alert.showAndWait();
        } else {
            appDialogs.signUp();
        }
    }

    /** Set the user of the client side. This is used when signing in, signing out or creating a new user
     *
     * @param user to set as Online
     */
    public void setOnlineUser(User user) {
        if (!appController.isGameRunning() && !gameSelectionOn) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            if (user != null) {
                alert.setTitle("User logged in!");
                alert.setHeaderText("Welcome " + user.getName());
            } else {
                alert.setTitle("Logged out!");
                alert.setHeaderText("You are logged out!");
            }
            onlineState.setSignedInUser(user);
            alert.showAndWait();
        }
    }

    /** refresh list of games from backend
     *
     */
    public void refreshGames() {
        try {
            List<Game> games = restClient.get()
                    .uri("/game/getGames")
                    .retrieve()
                    .body(new ParameterizedTypeReference<List<Game>>() {
                    });

            onlineState.setOpenGames(games != null ? games : new ArrayList<>());
        } catch (Exception e) {
            onlineState.setOpenGames(new ArrayList<>());
        }
    }

    private boolean gameSelectionOn = false;

    /** functionality for "Select Online Game" button. When pressed refresh list of games, go into gameSelectionPhase (gameSelectionOn),
     * and create the gameSelectionView using this OnlineController. <p>
     *     If you are not signed in, then a message will appear telling you to sign in before trying to select an online game.
     * </p> <p>
     *     If you are already playing a game, then you cannot select a new game
     * </p>
     *
     */
    public void selectGame() {
        if (appController.isGameRunning()) { // is currently not working
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Game running");
            alert.setHeaderText("You cannot select a game while a game is running!");
            alert.showAndWait();
        } else if (onlineState.getSignedInUser() == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Not signed in");
            alert.setHeaderText(
                    "You cannot select a game when not signed in!\n" +
                            "Sign in first!");
            alert.showAndWait();
        } else {
            refreshGames();
            gameSelectionOn = true;
            appController.roboRally.createGameSelectionView(this);
        }
    }

    /**
     * Handles the selection of an online game.
     * The selected game is set to ACTIVE in the backend
     * and then started locally on the client.
     *
     * @param game the selected game to start
     */
    public void gameSelected(Game game) {
        if (!appController.isGameRunning() /* && onlineState.getSignedInUser() != null && gameSelectionOn */) {
            appController.roboRally.createGameSelectionView(null);
            gameSelectionOn = false;
            try {
            if (game != null) {
                Game stateUpdate = new Game();
                stateUpdate.setGameState(Game.GameState.ACTIVE);
                    Game result = restClient.patch()
                            .uri("/game/{id}", game.getUid())
                            .body(stateUpdate)
                            .retrieve()
                            .body(Game.class);
                // Then show the game board and the game (with uid from backend) is then started
                assert result != null;
                startGame(result);
            }
            } catch (HttpClientErrorException.NotFound | HttpClientErrorException.Conflict e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(e.getMessage());
                alert.showAndWait();
            }
        }
    }

    /** Creates a new game using POST method if a game is not running & a user is signed in & if you are in gameSelection mode
     *
     * @param game the game that a player wants to make
     */
    public void createGame(Game game) {
        try {
            if (!appController.isGameRunning() && onlineState.getSignedInUser() != null && gameSelectionOn) {
                game.setOwner(onlineState.getSignedInUser());

                restClient.post()
                        .uri("/game")
                        .body(game)
                        .retrieve()
                        .body(Game.class);
                // update the game select view (which should get the new game from the backend)
                selectGame();
        }} catch (HttpClientErrorException.Conflict ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(ex.getMessage());
            alert.showAndWait();
        }
    }

    /**
     * functionality for create new game button. This will load a new Dialog, where the user will enter game details in order to create a new game
     */
    public void createGame() {
        appDialogs.createNewGame();
    }

    /**
     * join the given game as the currently active user.
     * This will add the user as a player to the game in the backend,
     * and then update the game select view.
     * @param game the game that a player wants to join
     */
    public void joinGame(Game game) {
        User currUser = onlineState.getSignedInUser();
        Player player = new Player();

        //referencing the whole object will create some errors or conflicts from the ID's and creating new players.
        //therefore new games and users are created client side.
        Game gameRef = new Game();
        gameRef.setUid(game.getUid());
        player.setGame(gameRef);


        User userRef = new User();
        userRef.setUid(currUser.getUid());
        userRef.setName(currUser.getName());
        player.setUser(userRef);
        player.setName(currUser.getName());

        //added to make sure you cant join a un-joinable game
        refreshGames();

        try {
                Player created = restClient.post()
                        .uri("/player")
                        .body(player)
                        .retrieve()
                        .body(Player.class);
        } catch (HttpClientErrorException.Conflict | HttpClientErrorException.NotFound ex) { //catches back end errors that are thrown from the PlayerService and PlayerController and shows the error message in an alert
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(ex.getMessage());
            alert.showAndWait();
        } finally {
            selectGame();
        }
    }

    /**
     * leave the given game as the currently active user.
     * This will delete the player corresponding to the user and the game in the backend,
     * @param player active user's player.
     */
    public void leaveGame(Player player) {
        try {
            restClient.delete().uri("/player/{playerUid}", player.getUid())
                    .retrieve()
                    .toBodilessEntity();
        } catch (Exception ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(ex.getMessage());
            alert.showAndWait();
        } finally {
            selectGame();
        }
    }

    /**
     *  Deletes the given game. This will delete the game in the backend, and then update the game select view.
     *  The deletion of the players are happening in the backend through the use of CASCADE on delete.
     * @param game the game that will be deleted
     */
    public void deleteGame(Game game) {
        try {
            restClient.delete().
                    uri("/game/{id}", game.getUid())
                    .retrieve()
                    .toBodilessEntity();
        } catch (Exception ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(ex.getMessage());
            alert.showAndWait();
        } finally {
            selectGame();
        }
    }

    /**
     *  Checks if the current user is a player in the given game.
     *  This is used to determine whether the user can join or leave the game, and whether they can start the game.
     *
     * @param game the game to check if the user is a player in
     * @return boolean whether or not the player is in the game
     */
    public boolean userInGame(Game game) {
        User currUser = onlineState.getSignedInUser();
        for (Player p : game.getPlayers()) {
            if (p.getUser().getUid() == currUser.getUid()) {
                return true;
            }
        }
        return false;
    }

    /**
     *
     * Checks if the current user owns the game.
     * This is used to determine whether the user can delete the game or not. Only the owner of the game can delete it.
     *
     * @param game the game to check whether the current user owns it or not
     * @return boolean for whether or not the user owns the game
     */
    public boolean userOwnsGame(Game game) {
        if (game.getOwner() == null) {
            game.setOwner(onlineState.getSignedInUser());
        }
        if (game.getOwner().getUid() == onlineState.getSignedInUser().getUid()) {
            return true;
        }

        return false;
    }

    /**
     * functionality for start game button. Sets up the board etc.
     * Is called when a game is selected and all a valid state exists to begin said game.
     *
     * @param game
     * no return (void)
     */
    private void startGame(Game game) {
        Game stateUpdate = new Game();
        stateUpdate.setGameState(Game.GameState.ACTIVE);

        refreshGames();

        try {
            Game updatedGame = restClient.patch()
                    .uri("/game/{id}", game.getUid())
                    .body(stateUpdate)
                    .retrieve()
                    .body(Game.class);

        } catch ( HttpClientErrorException.NotFound | HttpClientErrorException.Conflict e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(e.getMessage());
            alert.showAndWait();
        }

        Board board = new Board(8, 8); // no need to make it rely on the game info since as stated we arent working on the interactive gameplay stuff
        GameController gameController = new GameController(board);

        int i = 0;
        for (Player player : game.getPlayers()) {
            String name = player.getName();
            if (name == null) {
                name = "Player " + (i + 1);
            }
            dk.dtu.compute.se.pisd.roborally.model.Player p =
                    new dk.dtu.compute.se.pisd.roborally.model.Player(board, appController.PLAYER_COLOURS.get(i), name);
            board.addPlayer(p);
            p.setSpace(board.getSpace(i % board.width, i));
            i++;
        }

        gameSelectionOn = false;
        gameController.startProgrammingPhase();
        appController.roboRally.createBoardView(gameController);
    }

}
