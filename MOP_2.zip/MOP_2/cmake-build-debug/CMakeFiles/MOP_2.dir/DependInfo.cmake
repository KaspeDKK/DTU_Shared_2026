
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/magnusfriis/Documents/GitHub/DTU_Shared_2026/MOP_2/controller.c" "CMakeFiles/MOP_2.dir/controller.c.o" "gcc" "CMakeFiles/MOP_2.dir/controller.c.o.d"
  "/Users/magnusfriis/Documents/GitHub/DTU_Shared_2026/MOP_2/main.c" "CMakeFiles/MOP_2.dir/main.c.o" "gcc" "CMakeFiles/MOP_2.dir/main.c.o.d"
  "/Users/magnusfriis/Documents/GitHub/DTU_Shared_2026/MOP_2/model.c" "CMakeFiles/MOP_2.dir/model.c.o" "gcc" "CMakeFiles/MOP_2.dir/model.c.o.d"
  "/Users/magnusfriis/Documents/GitHub/DTU_Shared_2026/MOP_2/view.c" "CMakeFiles/MOP_2.dir/view.c.o" "gcc" "CMakeFiles/MOP_2.dir/view.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
