file(REMOVE_RECURSE
  "CMakeFiles/MOP_2.dir/controller.c.o"
  "CMakeFiles/MOP_2.dir/controller.c.o.d"
  "CMakeFiles/MOP_2.dir/main.c.o"
  "CMakeFiles/MOP_2.dir/main.c.o.d"
  "CMakeFiles/MOP_2.dir/model.c.o"
  "CMakeFiles/MOP_2.dir/model.c.o.d"
  "CMakeFiles/MOP_2.dir/view.c.o"
  "CMakeFiles/MOP_2.dir/view.c.o.d"
  "MOP_2"
  "MOP_2.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/MOP_2.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
